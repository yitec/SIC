-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 24-10-2012 a las 17:02:37
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `bd_inventarios`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tbl_articulos`
-- 

CREATE TABLE `tbl_articulos` (
  `id` int(11) NOT NULL auto_increment,
  `id_categoria` int(11) default NULL,
  `codigo` varchar(20) collate utf8_spanish_ci default NULL,
  `nombre` varchar(100) collate utf8_spanish_ci default NULL,
  `e_minima` bigint(20) default NULL,
  `ubicacion` varchar(25) collate utf8_spanish_ci default NULL,
  `unidad` varchar(20) collate utf8_spanish_ci default NULL,
  `existencia` bigint(20) default NULL,
  `botella` smallint(6) default NULL,
  `c_botellas` bigint(20) default NULL,
  `estado` smallint(6) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci PACK_KEYS=0 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `tbl_articulos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tbl_bitacora`
-- 

CREATE TABLE `tbl_bitacora` (
  `id` int(11) NOT NULL auto_increment,
  `usuario` varchar(50) default NULL,
  `accion` varchar(200) default NULL,
  `fecha` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 PACK_KEYS=0 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `tbl_bitacora`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tbl_categorias`
-- 

CREATE TABLE `tbl_categorias` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(100) collate utf8_spanish_ci default NULL,
  `estado` smallint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci PACK_KEYS=0 AUTO_INCREMENT=15 ;

-- 
-- Volcar la base de datos para la tabla `tbl_categorias`
-- 

INSERT INTO `tbl_categorias` VALUES (1, 'Reactivos', 1);
INSERT INTO `tbl_categorias` VALUES (2, 'Cristaleria', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tbl_codigos`
-- 

CREATE TABLE `tbl_codigos` (
  `id` int(11) NOT NULL auto_increment,
  `id_articulo` int(11) default NULL,
  `codigo` varchar(20) collate utf8_spanish_ci default NULL,
  `volumen` varchar(50) collate utf8_spanish_ci default NULL,
  `estado` tinyint(4) default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci PACK_KEYS=0 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `tbl_codigos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tbl_reportes`
-- 

CREATE TABLE `tbl_reportes` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(100) NOT NULL,
  `link` varchar(100) default NULL,
  `estado` int(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 PACK_KEYS=0 AUTO_INCREMENT=5 ;

-- 
-- Volcar la base de datos para la tabla `tbl_reportes`
-- 

INSERT INTO `tbl_reportes` VALUES (1, 'Existencia General', 'existencia_general.php', 1);
INSERT INTO `tbl_reportes` VALUES (2, 'Articulos en existencia minima', 'existencia_minima.php', 1);
INSERT INTO `tbl_reportes` VALUES (3, 'Bitacora movimientos', 'bitacora_movimientos.php', 1);
INSERT INTO `tbl_reportes` VALUES (4, 'Listado de codigos', 'reporte_codigos.php', 1);
